#ifndef __WIFI_USER_H__
#define __WIFI_USER_H__

#include <stdint.h>

void WiFi_to_TFT(uint8_t * buf);
void WiFi_to_Test(uint8_t * buf);
void WiFi_to_Test2(uint8_t *buf);
void Light_task(void);


#endif