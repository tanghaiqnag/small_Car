#ifndef __gpio_H
#define __gpio_H

#include "stm32f4xx.h"
#include "sys.h"
#include "tba.h"

#define JP_01_Pin 						GPIO_Pin_9
#define JP_01_GPIO_Port 			GPIOB
#define JP_01_Out 						PBout(9)
#define JP_01_In 							PBin(9)

#define JP_07_Pin 			 			GPIO_Pin_15
#define JP_07_GPIO_Port  			GPIOB
#define JP_07_Out		 			   	PBout(15)
#define JP_07_In 							PBin(15)

#define JP_09_Pin 						GPIO_Pin_10
#define JP_09_GPIO_Port 			GPIOH
#define JP_09_Out 						PHout(10)
#define JP_09_In 							PHin(10)

#define JP_11_Pin 						GPIO_Pin_11
#define JP_11_GPIO_Port 			GPIOH
#define JP_11_Out 						PHout(11)
#define JP_11_In 							PHin(11)

#define JP_13_Pin 						GPIO_Pin_4
#define JP_13_GPIO_Port 				GPIOB
#define JP_13_Out 						PBout(4)
#define JP_13_In 						PBin(4)

#define JP_15_Pin 						GPIO_Pin_15
#define JP_15_GPIO_Port 				GPIOA
#define JP_15_Out 						PAout(15)
#define JP_15_In 						PAin(15)

#define JP_02_Pin 						GPIO_Pin_13
#define JP_02_GPIO_Port 			GPIOC
#define JP_02_Out   					PCout(13)
#define JP_02_In 							PCin(13)

#define JP_04_Pin 						GPIO_Pin_11
#define JP_04_GPIO_Port 			GPIOF
#define JP_04_Out 						PFout(11)
#define JP_04_In 							PFin(11)

#define JP_06_Pin 						GPIO_Pin_8
#define JP_06_GPIO_Port 			GPIOG
#define JP_06_Out 						PGout(8)
#define JP_06_In 							PGin(8)

#define JP_08_Pin 						GPIO_Pin_15
#define JP_08_GPIO_Port 			GPIOG
#define JP_08_Out 	   				PGout(15)
#define JP_08_In 							PGin(15)

#define JP_10_Pin 						GPIO_Pin_6
#define JP_10_GPIO_Port 			GPIOB
#define JP_10_Out    					PBout(6) 
#define JP_10_In 							PBin(6) 

#define JP_12_Pin 						GPIO_Pin_7
#define JP_12_GPIO_Port 			GPIOB
#define JP_12_Out   					PBout(7) 	 
#define JP_12_In  						PBin(7)  

#endif

#ifdef GuoSai_V1_0 //������IO��Ϣ

#define R_LED(In_Sig) 								{Set_CD4051_IT_Data(3,In_Sig);}												
#define R_LED_SET_Flag								0
#define R_LED_ON											{R_LED(R_LED_SET_Flag);}
#define R_LED_OFF											{R_LED(!R_LED_SET_Flag);}
#define R_LED_Initial_Value_Init 			{R_LED_OFF;}

#define L_LED(In_Sig) 								{Set_CD4051_IT_Data(4,In_Sig);}									
#define L_LED_SET_Flag								1
#define L_LED_ON											{L_LED(L_LED_SET_Flag);}
#define L_LED_OFF											{L_LED(!L_LED_SET_Flag);}
#define L_LED_Initial_Value_Init 			{L_LED_OFF;}
	
#define SMG_A(In_Sig)   							{Set_CD4051_IT_Data(0,In_Sig);}	 											
#define SMG_A_SET_Flag								1
#define SMG_A_ON											{SMG_A(SMG_A_SET_Flag);}
#define SMG_A_OFF											{SMG_A(!SMG_A_SET_Flag);}		
#define SMG_A_Initial_Value_Init 			{SMG_A_OFF;}	
	
#define SMG_B(In_Sig)   							{Set_CD4051_IT_Data(1,In_Sig);}	 											
#define SMG_B_SET_Flag								1
#define SMG_B_ON											{SMG_B(SMG_B_SET_Flag);}
#define SMG_B_OFF											{SMG_B(!SMG_B_SET_Flag);}		
#define SMG_B_Initial_Value_Init 			{SMG_B_OFF;}	

#define INC(In_Sig) 									{CD4051_SetPin(2,In_Sig);}			
#define INC_SET_Flag									0
#define INC_ON												{CD4051_IT_OFF();INC(INC_SET_Flag);}
#define INC_OFF												{INC(!INC_SET_Flag);CD4051_IT_ON();}	
#define INC_Initial_Value_Init 				{INC_OFF;Set_CD4051_IT_Data(2,!INC_SET_Flag);}

#define RI_TXD(In_Sig)   							{CD4051_SetPin(6,In_Sig);}	
#define RI_TXD_SET_Flag								0
#define RI_TXD_ON											{CD4051_IT_OFF();RI_TXD(RI_TXD_SET_Flag);}
#define RI_TXD_OFF										{RI_TXD(!RI_TXD_SET_Flag);CD4051_IT_ON();}	
#define RI_TXD_Initial_Value_Init 		{RI_TXD(!RI_TXD_SET_Flag);Set_CD4051_IT_Data(6,!RI_TXD_SET_Flag);}	
	
#define BEEP(In_Sig)   								{CD4051_SetPin(5,In_Sig);}	  											
#define BEEP_SET_Flag									0
#define BEEP_ON												{CD4051_IT_OFF();BEEP(BEEP_SET_Flag);}
#define BEEP_OFF											{BEEP(!BEEP_SET_Flag);CD4051_IT_ON();}		
#define BEEP_Initial_Value_Init 			{BEEP_OFF;Set_CD4051_IT_Data(5,!BEEP_SET_Flag);}		
	
/********************************************************************************************/

/********************************************************************************************/
/*01*******************************************************************************************/
#define SYN7318RESET_JP_Num				JP_06
#define SYN7318RESET_Pin 					JP_06_Pin
#define SYN7318RESET_GPIO_Port 		JP_06_GPIO_Port
#define SYN7318RESET_Initial_Value_Init	{GPIO_SetBits(SYN7318RESET_GPIO_Port,SYN7318RESET_Pin);}
#define SYN7318RESET 							JP_06_Out

/********************************************************************************************/
/*07*******************************************************************************************/

#define CD_4051_COM_JP_Num									JP_07
#define CD_4051_COM_Pin 			 							JP_07_Pin
#define CD_4051_COM_GPIO_Port 							JP_07_GPIO_Port
#define CD_4051_COM_Initial_Value_Init		 	{GPIO_SetBits(CD_4051_COM_GPIO_Port,CD_4051_COM_Pin);}
#define CD_4051_COM		 			 								JP_07_Out

/********************************************************************************************/
/*09*******************************************************************************************/

#define CD_4051_A_JP_Num					JP_09
#define CD_4051_A_GPIO_Port 			JP_09_GPIO_Port
#define CD_4051_A_Pin 						JP_09_Pin
#define CD_4051_A_Initial_Value_Init {GPIO_SetBits(CD_4051_A_GPIO_Port,CD_4051_A_Pin);}
#define CD_4051_A  								JP_09_Out
/********************************************************************************************/
/*11*******************************************************************************************/

#define CD_4051_B_JP_Num					JP_11
#define CD_4051_B_GPIO_Port 			JP_11_GPIO_Port
#define CD_4051_B_Pin 						JP_11_Pin
#define CD_4051_B_Initial_Value_Init {GPIO_SetBits(CD_4051_B_GPIO_Port,CD_4051_B_Pin);};
#define CD_4051_B  								JP_11_Out
/********************************************************************************************/
/*13*******************************************************************************************/

#define CD_4051_C_JP_Num					JP_13
#define CD_4051_C_GPIO_Port 			JP_13_GPIO_Port
#define CD_4051_C_Pin 						JP_13_Pin
#define CD_4051_C_Initial_Value_Init	{GPIO_SetBits(CD_4051_C_GPIO_Port,CD_4051_C_Pin);};
#define CD_4051_C  								JP_13_Out
/********************************************************************************************/
/*15*******************************************************************************************/

#define INT0_JP_Num								JP_15
#define INT0_Pin 									JP_15_Pin
#define INT0_GPIO_Port 						JP_15_GPIO_Port
#define INT0 											JP_15_In

#define EXTI_PortSource_GPIO_Port 			EXTI_PortSourceGPIOA
#define EXTI_PinSource_Num 					EXTI_PinSource15								//1.2.3.4.5.....
#define EXTI_Line_Num 						EXTI_Line15													//�ⲿ�ж�ͨ��1.2.3.4.5.....
#define EXTI_Num_IRQn 						EXTI15_10_IRQn													//�ⲿ�ж���EXTI1.2.3.4,EXTI9_5_IRQn,EXTI15_10_IRQn
#define EXTI_IRQHandler 					EXTI15_10_IRQHandler									//EXTI1.2.3.4,EXTI9_5_IRQHandler,EXTI15_10_IRQHandler

/********************************************************************************************/
/*02*******************************************************************************************/

#define SER_JP_Num								JP_01
#define SER_Pin 									JP_01_Pin
#define SER_GPIO_Port 						JP_01_GPIO_Port
#define SER   										JP_01_Out

/********************************************************************************************/
/*04*******************************************************************************************/
#define RCK_JP_Num								JP_04
#define RCK_Pin 									JP_04_Pin
#define RCK_GPIO_Port 						JP_04_GPIO_Port
#define RCK   										JP_04_Out

/********************************************************************************************/
/*06*******************************************************************************************/

#define SCK_JP_Num								JP_02
#define SCK_Pin 									JP_02_Pin
#define SCK_GPIO_Port 						JP_02_GPIO_Port
#define SCK   										JP_02_Out

/********************************************************************************************/
/*08*******************************************************************************************/
#define ADDR_JP_Num								JP_08
#define ADDR_Pin 									JP_08_Pin
#define ADDR_GPIO_Port 						JP_08_GPIO_Port
#define ADDR 	   									JP_08_Out

/********************************************************************************************/
/*10*******************************************************************************************/
#define IIC_SDA_JP_Num						JP_10
#define IIC_SDA_Pin 							JP_10_Pin
#define IIC_SDA_GPIO_Port 				JP_10_GPIO_Port
#define IIC_SDA    								JP_10_Out //SDA���	 
#define READ_SDA   								JP_10_In  //SDA���� 

/********************************************************************************************/
/*12*******************************************************************************************/
#define IIC_SCL_JP_Num						JP_12
#define IIC_SCL_Pin 							JP_12_Pin
#define IIC_SCL_GPIO_Port 				JP_12_GPIO_Port
#define IIC_SCL    								JP_12_Out //SCL 
#endif

#ifdef ShengSai_V1_0

/*4051*******************************************************************************************/

//#define R_LED(In_Sig) 								{Set_CD4051_IT_Data(0,In_Sig);}												
//#define R_LED_SET_Flag								0
//#define R_LED_ON											{R_LED(R_LED_SET_Flag);}
//#define R_LED_OFF											{R_LED(!R_LED_SET_Flag);}
//#define R_LED_Initial_Value_Init 					{R_LED_OFF;}

//#define L_LED(In_Sig) 								{Set_CD4051_IT_Data(1,In_Sig);}									
//#define L_LED_SET_Flag								1
//#define L_LED_ON											{L_LED(L_LED_SET_Flag);}
//#define L_LED_OFF											{L_LED(!L_LED_SET_Flag);}
//#define L_LED_Initial_Value_Init 			{L_LED_OFF;}
	
/********************************************************************************************/
/*08*******************************************************************************************/
#define INC_JP_Num											JP_15
#define INC_Pin 												JP_15_Pin
#define INC_GPIO_Port 									JP_15_GPIO_Port
#define INC_Out 	   										JP_15_Out

#define SMG_JP_Num											JP_02
#define SMG_Pin 												JP_02_Pin
#define SMG_GPIO_Port 									JP_02_GPIO_Port
#define SMG_Out 	   										JP_02_Out

#define BEEP_JP_Num											JP_02
#define BEEP_Pin 												JP_02_Pin
#define BEEP_GPIO_Port 									JP_02_GPIO_Port
#define BEEP_Out 	   										JP_02_Out

#define RI_TXD_JP_Num										JP_04
#define RI_TXD_Pin 											JP_04_Pin
#define RI_TXD_GPIO_Port 								JP_04_GPIO_Port
#define RI_TXD_Out 	   									JP_04_Out

#define SMG(In_Sig) 										{JP_02_Out=In_Sig;}												
#define SMG_SET_Flag										0
#define SMG_ON													{SMG(SMG_SET_Flag);}
#define SMG_OFF													{SMG(!SMG_SET_Flag);}
#define SMG_Initial_Value_Init 					{SMG_OFF;}

#define R_LED(In_Sig) 									{JP_11_Out=In_Sig;}												
#define R_LED_SET_Flag									0
#define R_LED_ON												{R_LED(R_LED_SET_Flag);}
#define R_LED_OFF												{R_LED(!R_LED_SET_Flag);}
#define R_LED_Initial_Value_Init 				{R_LED_OFF;}

#define L_LED(In_Sig) 									{JP_09_Out=In_Sig;}													
#define L_LED_SET_Flag									0
#define L_LED_ON												{L_LED(L_LED_SET_Flag);}
#define L_LED_OFF												{L_LED(!L_LED_SET_Flag);}
#define L_LED_Initial_Value_Init 				{L_LED_OFF;}

/********************************************************************************************/
/*10*******************************************************************************************/

	
#define INC(In_Sig) 										{JP_15_Out = In_Sig;}	//{CD4051_SetPin(4,In_Sig);}			
#define INC_SET_Flag										0						
#define INC_ON													{INC(INC_SET_Flag);}		//{CD4051_IT_OFF();INC(INC_SET_Flag);}
#define INC_OFF													{INC(!INC_SET_Flag);}	//{INC(!INC_SET_Flag);CD4051_IT_ON();}	
#define INC_Initial_Value_Init 					{INC(!INC_SET_Flag);}	//{INC_OFF;Set_CD4051_IT_Data(4,!INC_SET_Flag);}

#define RI_TXD(In_Sig)   								{JP_04_Out = In_Sig;}	
#define RI_TXD_SET_Flag									0
#define RI_TXD_ON												{RI_TXD(RI_TXD_SET_Flag);}	//{CD4051_IT_OFF();RI_TXD(RI_TXD_SET_Flag);}
#define RI_TXD_OFF											{RI_TXD(!RI_TXD_SET_Flag);}	//{RI_TXD(!RI_TXD_SET_Flag);CD4051_IT_ON();}	
#define RI_TXD_Initial_Value_Init 			{RI_TXD(!RI_TXD_SET_Flag);} //{RI_TXD(!RI_TXD_SET_Flag);Set_CD4051_IT_Data(5,!RI_TXD_SET_Flag);}	
	
#define BEEP(In_Sig)   									{JP_02_Out = In_Sig;}		//{CD4051_SetPin(6,In_Sig);}	  											
#define BEEP_SET_Flag										0
#define BEEP_ON													{BEEP(BEEP_SET_Flag);}		//{CD4051_IT_OFF();BEEP(BEEP_SET_Flag);}
#define BEEP_OFF												{BEEP(!BEEP_SET_Flag);}		//{BEEP(!BEEP_SET_Flag);CD4051_IT_ON();}		
#define BEEP_Initial_Value_Init 				{BEEP(!BEEP_SET_Flag);}     //{BEEP_OFF;Set_CD4051_IT_Data(6,!BEEP_SET_Flag);}		
	
/********************************************************************************************/

/********************************************************************************************/
/*01*******************************************************************************************/
#define SYN7318RESET_JP_Num							JP_01
#define SYN7318RESET_Pin 								JP_01_Pin
#define SYN7318RESET_GPIO_Port 					JP_01_GPIO_Port
#define SYN7318RESET_Initial_Value_Init	{GPIO_SetBits(SYN7318RESET_GPIO_Port,SYN7318RESET_Pin);}
#define SYN7318RESET 										JP_01_Out

#define SMG_A(In_Sig)   								{JP_02_Out=In_Sig;}	//{Set_CD4051_IT_Data(2,In_Sig);}	 											
#define SMG_A_SET_Flag									0
#define SMG_A_ON												{SMG_A(SMG_A_SET_Flag);}
#define SMG_A_OFF												{SMG_A(!SMG_A_SET_Flag);}		
#define SMG_A_Initial_Value_Init 				{SMG_A_OFF;}	
	
#define SMG_B(In_Sig)   								{JP_02_Out=In_Sig;}	//{Set_CD4051_IT_Data(3,In_Sig);}	 											
#define SMG_B_SET_Flag									1
#define SMG_B_ON												{SMG_B(SMG_B_SET_Flag);}
#define SMG_B_OFF												{SMG_B(!SMG_B_SET_Flag);}		
#define SMG_B_Initial_Value_Init 				{SMG_B_OFF;}	

#define INT0_JP_Num											JP_13
#define INT0_Pin 												JP_13_Pin
#define INT0_GPIO_Port 									JP_13_GPIO_Port
#define INT0 														JP_13_In

#define EXTI_PortSource_GPIO_Port 			EXTI_PortSourceGPIOB
#define EXTI_PinSource_Num 							EXTI_PinSource4								//1.2.3.4.5.....
#define EXTI_Line_Num 									EXTI_Line4													//�ⲿ�ж�ͨ��1.2.3.4.5.....
#define EXTI_Num_IRQn 									EXTI4_IRQn													//�ⲿ�ж���EXTI1.2.3.4,EXTI9_5_IRQn,EXTI15_10_IRQn
#define EXTI_IRQHandler 								EXTI4_IRQHandler									//EXTI1.2.3.4,EXTI9_5_IRQHandler,EXTI15_10_IRQHandler

/********************************************************************************************/
/*02*******************************************************************************************/

#define SER_JP_Num											JP_07
#define SER_Pin 												JP_07_Pin
#define SER_GPIO_Port 									JP_07_GPIO_Port
#define SER   													JP_07_Out

/********************************************************************************************/
/*04*******************************************************************************************/
#define RCK_JP_Num											JP_09
#define RCK_Pin 												JP_09_Pin
#define RCK_GPIO_Port 									JP_09_GPIO_Port
#define RCK   													JP_09_Out

/********************************************************************************************/
/*06*******************************************************************************************/

#define SCK_JP_Num											JP_11
#define SCK_Pin 												JP_11_Pin
#define SCK_GPIO_Port 									JP_11_GPIO_Port
#define SCK   													JP_11_Out

/********************************************************************************************/
/*08*******************************************************************************************/
#define ADDR_JP_Num											JP_08
#define ADDR_Pin 												JP_08_Pin
#define ADDR_GPIO_Port 									JP_08_GPIO_Port
#define ADDR 	   												JP_08_Out

/********************************************************************************************/
/*10*******************************************************************************************/
#define IIC_SDA_JP_Num									JP_12
#define IIC_SDA_Pin 										JP_12_Pin
#define IIC_SDA_GPIO_Port 							JP_12_GPIO_Port
#define IIC_SDA    											JP_12_Out //SDA���	 
#define READ_SDA   											JP_12_In  //SDA���� 

/********************************************************************************************/
/*12*******************************************************************************************/
#define IIC_SCL_JP_Num									JP_10
#define IIC_SCL_Pin 										JP_10_Pin
#define IIC_SCL_GPIO_Port 							JP_10_GPIO_Port
#define IIC_SCL    											JP_10_Out //SCL 

/********************************************************************************************/
/********************************************************************************************/

#endif


void MX_GPIO_Init(void);
