#include "Mylib.h"
#include "delay.h"
#include "Motion.h"
#include "canp_hostcom.h"
#include "Init_marker.h"
#include "Marker.h"
#include "bh1750.h"
#include "infrared.h"
#include "data_base.h"
#include "can_user.h"
#include "roadway_check.h"
#include "Timer.h"
#include <string.h>
#include <stdio.h>
#include "RC522.h"
#include "A72.h"
#include "Init_marker.h"
#include "Integration_task.h"
#include "Typ.h"
#include "stdio.h"	
#include "stdarg.h"	
#define BUFFER_SIZE	100
MylibInitTypeDef Mylib = { 0 };

//����wifi����A72 ����ǰ���ٶ� �Լ� ����ʮ��·�ھ��� 
void Init_GoValue(void)
{
//	if (Mylib.A72_ENABLE == 0){ //
//		Mylib.go_value = 360;
//		Mylib.Go_Value_Line_Middle.Length = 1000;
//		Mylib.Go_Value_Line_Middle.Width = 850;
//	}
//	else {
		Mylib.go_value = 360-60;
		Mylib.Go_Value_Line_Middle.Length = 1000+90;
		Mylib.Go_Value_Line_Middle.Width = 850+90;
//	}
		
}

void printf_LCD(char *date,...)	//����1��printf����
{
	char buf[BUFFER_SIZE];		//���巢�ͻ������Ĵ�С
	uint16_t i;
	
	va_list arg_ptr;
	va_start(arg_ptr,date);
	
	vsnprintf(buf,BUFFER_SIZE,date,arg_ptr);
	
	Send_InfoData_To_Fifo((u8 *)buf,strlen(buf)); 
	
	va_end(arg_ptr);
}

