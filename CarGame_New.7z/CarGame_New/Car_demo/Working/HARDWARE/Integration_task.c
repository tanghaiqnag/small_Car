#include <stdio.h>
#include "stm32f4xx.h"
#include "delay.h"
#include "infrared.h"
#include "cba.h"
#include "ultrasonic.h"
#include "canp_hostcom.h"
#include "hard_can.h"
#include "bh1750.h"
#include "xiaochuang.h"
#include "power_check.h"
#include "can_user.h"
#include "data_base.h"
#include "roadway_check.h"
#include "tba.h"
#include "data_base.h"
#include "swopt_drv.h"
#include "uart_a72.h"
#include "Can_check.h"
#include "delay.h"
#include "can_user.h"
#include "Timer.h"
#include "Rc522.h"
#include "A72.h"
#include "Digital_track.h"
#include "Motion.h"
#include "Integration_task.h" 
#include "gpio.h"
#include "Init_marker.h"
#include "Marker.h"
#include "Mylib.h"
#include "HS_Send.h"
#include "HS_Rec_Data_Pro.h"
#include <math.h>
#include "Mark_To_MasterCar_DataSlove.h"
unsigned char Data_Set_All = 1; //ȫ���޸Ĳ��Բ���

extern int zig_rec_flag;
extern uint8_t ASR[6];
uint16_t Range_Go=0;
uint16_t MO6=0;
uint8_t read_car_num=0;
unsigned char Temp = 0;

void Process_Task(uint8_t Markers)
{
	uint16_t dis_value = 0;
	switch(Markers) {
		case Terrain_ENUM: {		//����
				terrain_track(); 		//�ó�ͨ������
			//track_PID(70);                  // �ߵ�ʮ��·��  			
			//go_forward(60, Mylib.go_value); // �ߵ�ʮ��·���м�
			//			correct_trackGo(60, 200, 1, 1);//��������
			//			terrain_rfid_track(2564, 2, 1);
			//			terrain_rfid_track();
		}
			break;
		case RFID_ENUM:	{		

				track_readRFID();

		}
			break;
		case TFTA_ENUM: {				//TFTA
			
			
			Init_TFT();
			
			printf_LCD("TFTA");
			Identify_TFT('A');
			uint8_t Hex1[3] = {0x20,0x23,0x03};
			TFT_displayHex('A',Hex1);

			
		}
			break;
		
		case TFTB_ENUM: {				//TFTB
			
			Init_TFT();
			Identify_TFT('B');//TFTʶ��				//pos 3

			uint8_t Hex1[3] = {0x34,0x23,0x21};
			TFT_displayHex('B',Hex1);
			
			}
			break;
		case TFTC_ENUM: {				//TFTC
		
			
			Init_TFT();
			Identify_TFT('C');
			
			uint8_t Hex1[3] = {0xFF,0xFF,0x07};
			TFT_displayHex('C',Hex1);
			}
			break;
		
		case Liti_ENUM:	{				//������ʾ
			Init_Liti();
			LITI_Run();
			}
			break;
		case SYN_ENUM: {				//��������
			//correct_trackBack(60,40, 0, 1);
			//go_forward(65, Mylib.go_value);
			uint8_t temp[6]={0};
			uint8_t voice=0;
			uint8_t Time=0;
			uint8_t flag = 0;
			voice=BKRC_Voice_Extern(0);
			
			if(voice==0xff&&Time<2)
			{
				voice=BKRC_Voice_Extern(0);
				Time++;
			}
			
			
			auto_grade(voice);
			Time = 0;
			while(flag == 0 && Time < 3)
			{
				Voice_InquireClimate();
				delay_ms(200);
				if(voice_Location!=0)
				{
					Temp = voice_Location;
					Marker_InitStruct.Garage_B.Rise_Num = (Temp%4)+1;
					
					flag = 1;
					printf_LCD("%d\n",voice_Location);
				}
			}
			delay_ms(1000);
			
			
			//temp[1]=voice/16;
			//temp[2]=voice*16;
			//led_secondData(temp);
			//turn_right_mapan(90, 500);
			//turn_left_mapan(90, 500);
			}
			break;

		case Light_ENUM: {			//����·��,���ҵ�λ
			uint8_t a;
			init_light();											//����·�Ƴ�ʼ��
			Marker_InitStruct.Light.FirstGear = get_light(&Marker_InitStruct);	
			
			delay_ms(500);
			set_light(&Marker_InitStruct);
			

				}
			break;
		case TrafficA_ENUM: {		//��ͨ��A
			Init_TRAFFIC();
			if (Marker_InitStruct.TRAFFIC_A.correct_track == ENABLE) {	//����·��
				correct_trackBack(60, 40, 0, 1);
				go_forward(60, Mylib.go_value + 30);
			}
			Identify_Trafficlight('A');	
		}
			break;
		case Terrain_RFID_ENUM:{	//���κ�RFID���
			terrain_rfid_track(4);			
			delay_ms(500);
			
			}
			break;
		case TrafficB_ENUM: {		//��ͨ��B
				if (Marker_InitStruct.TRAFFIC_B.correct_track == ENABLE) {	//����·��->TRAFFIC_B_correct_track
				correct_trackBack(60, 40, 0, 1);
				go_forward(60, Mylib.go_value + 30);
			}
				correct_trackBack(60, 40, 0, 1);
				go_forward(60, Mylib.go_value + 30);
				Identify_Trafficlight('B');

			}
			break;
			case TrafficC_ENUM: {		//��ͨ��C
//			back_up(60, 600);				//450
				//Init_TRAFFIC();
				if (Marker_InitStruct.TRAFFIC_C.correct_track == ENABLE) {	//����·��->TRAFFIC_B_correct_track
				correct_trackBack(60, 40, 0, 1);
				go_forward(60, Mylib.go_value + 30);
			}
				correct_trackBack(60, 40, 0, 1);
				go_forward(60, Mylib.go_value + 30);
				Identify_Trafficlight('C');

			}
			break;
			case TrafficD_ENUM: {		//��ͨ��D
//			back_up(60, 600);				//450
				//Init_TRAFFIC();
				if (Marker_InitStruct.TRAFFIC_D.correct_track == ENABLE) {	//����·��->TRAFFIC_B_correct_track
					correct_trackBack(60, 40, 0, 1);
					go_forward(60, Mylib.go_value + 30);
				}
				correct_trackBack(60, 40, 0, 1);
				go_forward(60, Mylib.go_value + 30);
				Identify_Trafficlight('D');

			}
			break;
		
		case Alarm_ENUM: {			//����̨
//			track_back(60,1);
//			back_up(60,500);
			Init_Alarm();													//���̨��ʼ��		
			alarm_send();
			//SYN_TTS((uint8_t *)"���̨���Ϳ��������");   ���ǰ�����Ĵ���
			delay_ms(200);
		}
			break;
		case Code_ENUM: {				//��ά��
			
			Init_Code();
			//go_forward(60, Mylib.Go_Value_Line_Middle.Width);
			track_PID_delay(60,80);
			Identify_QRCode();
			track_PID(60);
			go_forward(65, Mylib.go_value);
			}
			break;
		case NoRFID_ENUM:	{			//����RFID
			track_noReadRFID(60); 
			go_forward(60, Mylib.go_value);
		}
		
			break;
		case ETC_ENUM: {				//ETC
			//correct_trackBack(60, 40, 0, 1);
			//go_forward(60, Mylib.go_value);
			//delay_ms(500);
			ETC_open();
			track_PID_RFID(60);	
			//track_PID(70);//�ߵ�ʮ��·��
			//go_forward(60, Mylib.go_value);//�ߵ�ʮ��·���м�

		}
			break;
		case Range_ENUM: {			//���
				//correct_trackGo(60, 360, 0, 0);
				//correct_trackBack(60, 40, 0, 0);
				back_up(60, 360);
				delay_ms(500);
				Mylib.distance_value = get_range();
				//led_displayDistance(Mylib.distance_value);
			TFT_displayDistance('A', Mylib.distance_value);
				go_forward(60,Mylib.go_value);
				ToA72_SendRange(Mylib.distance_value);
				//if(Mylib.distance_value>200)
				//{
					//Range_Go=(Mylib.distance_value-170)*3/2;//3/2�����̺�mmת������
					//go_forward(60,Range_Go);
				//}
				//ToA72_SendRange(Mylib.distance_value);
			}
			break;
		case Task_ENUM: //���ͳ�����Ϣ���ӳ�
		{				//��������
			{
				int i=0;
				HS_Data_Typ shuju;
				memset(&shuju, 0, sizeof(shuju));
				shuju.Fun_Data_Num=Save_Plate_Date;
				shuju.Fun_Data_Len=10;
				for(i=0;i<shuju.Fun_Data_Len;i++)
				{
					shuju.Data[i]=TFTData.plate.Data[0][i];//��һ�ų��Ƶ�����
					printf_LCD("%c\n",TFTData.plate.Data[0][i]);
				}
				HS_Interactive_Com(&shuju);
				
			}
		}
			break;
		case Static_ENUM: {					//��̬��־��ͼ��
			dis_value = get_range();
			while (!(dis_value >= 230 && dis_value <= 270)) {
				go_forward(60, 50);
				dis_value = get_range();
			}
			delay_ms(1000);
			ToA72_RecgJintai(1);
//			ToA72_SetCameraPos(Marker_InitStruct.CODE.Recognition_Par->SetCameraPos);//��A72��������ͷԤ��λ
		}
			break;
		case Park_Correct_ENUM: {		//ͣ������
			correct_trackBack(60, 40, 0, 0);
			go_forward(60, Mylib.go_value+90);
			
			//			track_PID(50);
		}
			break;
		case WaitSTrack_ENUM:{			//�����ӳ�����Ϣ
				//char buf[]= "B1D3E3E5|D1";
				//correct_trackGo(60, 360, 0, 0);
				
				HS_Data_Typ kia;
				memset(&kia, 0, sizeof(kia));
				
				kia.Fun_Data_Num=Start;
				kia.Fun_Data_Len=1;
				//memcpy(kia.Data,buf,16);
				//kia.Data[0]=TFTData.TrafficSign.Data[0];
				//printf_LCD((char *)"\n%d\n",kia.Data[0]);
				HS_Interactive_Com(&kia);
				back_up(60, 500);
				back_up(60, 500);
		}
		break;
		
		case Gate_ENUM: {		//����բ
			//gate_open();
			//ThroughGate((uint8_t *)TFTData.plate.Data[0]);
			ThroughGate("230805");
			
			
		}
			break;
		case L_Mapan_ENUM: {		//����90��
			turn_left_mapan(90, 840);
			if(Current>1){
				Current-=1;
			}
			else{
				Current=4;
			}
			
		}
			break;
		case R_Mapan_ENUM: {		//����90��
			turn_right_mapan(90, 840);
			if(Current<4){
				Current+=1;
			}
			else{
				Current=1;
			}
		}
			break;
		case Avoid_ENUM: {		//���	���� ��A72-���̣�1185 �У�1110 ������ת����1800

			back_up(60, 1185);
		}
			break;
		case LED_Tba_ENUM: {
//			L_LED_ON;
//			R_LED_ON;
		}
			break;
		case Go_ENUM:			//ǰ��
			go_forward(60, Mylib.Go_Value_Line_Middle.Width);
			break;
		case Back_ENUM:		//����
			back_up(60, Mylib.Go_Value_Line_Middle.Width);
			break;
		
		case Host_Con_Slave_Run_ENUM:
			Process_RFID_Data(RFID.Read_Add[0].RFID_result);
		
			break;
		case Slave_Con_Host_Run_ENUM:			
			break;
		case Stop_HostCar_ENUM:	
			break;
		default:
			break;
	}
}

void Init_Task(void)			//��ʼ���������
{
	//uint8_t riqi[3]={0x20,0x23,0x03};
	//led_secondData(riqi);
	//delay_ms(10);
	//led_secondData(riqi);
	
	led_clear();
	delay_ms(100);
	led_timerOpen();
	char Debug_Temp[]="Gar_Init_OK\n";
	Send_InfoData_To_Fifo((u8 *)Debug_Temp,strlen(Debug_Temp));
	//Garage_Reduction();
	//go_forward(60,360);
	//Marker_InitStruct.Garage_Now_Doing_Typ = B;
	
	//track_PID_RFID(60);	
	
	
//	delay_ms(100);
//	ToA72_SetCameraPos(1);
//	delay_ms(100);
//	TFT_pageUp('A');
//	delay_ms(100);
	
		
		//delay_ms(100);

	//delay_ms(100);

}
void Finish_Task(void)		//�����������
{
	delay_ms(500);
	
	
	delay_ms(100);
	wireless_chargeOpen();//���߳��
	delay_ms(100);
	led_timerClose();
	
	//HS_Data_Typ kia;
	//memset(&kia, 0, sizeof(kia));
	//kia.Fun_Data_Num=Go;
	//HS_Interactive_Com(&kia);
	
//	shumaguanflag=1;
//#if	Debug_Little 
//	L_LED = ~L_LED;
//	R_LED = ~R_LED;
////	BEEP = ~BEEP;
//#endif
	
//	L_LED_OFF;
//	R_LED_OFF;
	
//	#if Debug_Little == 0
//	cd4051_flag = 1;
//	SMG_flag = 1;
//	#endif
	
}

//ѭ���ƻص��м�
void terrain_infrared(void)
{
	uint8_t count = 0;
	uint8_t Infared_Value = Get_Host_UpTrack(TRACK_H8);			//��ȡ���λ����ֵ
	for (int i = 0x01;i < 0x100;i <<= 1,count++) {
		if ((Infared_Value & i) == 0) {
			break;
		}
	}
	if (count < 3) {			//��ת
		Send_UpMotor(60,-60);		
		while((Infared_Value &0X10)) {
			Infared_Value = Get_Host_UpTrack(TRACK_H8);
		}
		Send_UpMotor(0,0);
	}
	else if (count > 4) {		//��ת
		Send_UpMotor(-60,60);
		while((Infared_Value &0X08)) {
			Infared_Value = Get_Host_UpTrack(TRACK_H8);
		}
		Send_UpMotor(0,0);
	}
}

uint16_t get_range(void)	//���
{
	float range_ad;
	uint16_t range;
//	uint16_t range = Ultrasonic_Measure()-32; 					//������
//	uint16_t range = Ultrasonic_Measure()*2; 					//������
	range_ad = Ultrasonic_Measure();							//���ĵ�һ����������20
//	range_ad = Ultrasonic_Measure()-10;

	return range_ad;
}

void range_track(void)
{
	back_up(60,800);
	track_noReadRFID(60);
	delay_ms(200);
}

/*****************************
*ʶ��TFT
*****************************/
void Identify_TFT(uint8_t Mark)					
{
	Marker_InitTypeDef *Marker = &Marker_InitStruct;
	uint8_t set_pos;// = AorB == 'A' ? Marker_InitStruct.TFTA.SetCameraPos : Marker_InitStruct.TFTB.SetCameraPos;
	switch(Mark)		//��ͷ
	{
		case 'A':
			set_pos = Marker_InitStruct.TFTA.SetCameraPos;
			break;
		case 'B':
			set_pos = Marker_InitStruct.TFTB.SetCameraPos;
			break;
		case 'C':
			set_pos = Marker_InitStruct.TFTC.SetCameraPos;
			break;
		default:	
			break;
	}
	
	ToA72_SetCameraPos(set_pos);//��A72��������ͷԤ��λ
	delay_ms(2500);			//�ȴ�����ͷ��Ԥ��λ
	
	if (Switch_TFT == 1) {			//TFT����
		ToA72_RecgTFT(Mark);
	} else {delay_ms(500);}
}


/******************************
*ʶ��ͨ��
*******************************/
void Identify_Trafficlight(uint8_t Mark)
{
	Marker_InitTypeDef *Marker = &Marker_InitStruct;
	uint8_t set_pos;
	switch(Mark)		//��ͷ
	{
		case 'A':
			set_pos = Marker_InitStruct.TRAFFIC_A.SetCameraPos;
			break;
		case 'B':
			set_pos = Marker_InitStruct.TRAFFIC_B.SetCameraPos;
			break;
		case 'C':
			set_pos = Marker_InitStruct.TRAFFIC_C.SetCameraPos;
			break;
		case 'D':
			set_pos = Marker_InitStruct.TRAFFIC_D.SetCameraPos;
			break;
		default:	
			break;
	}
	//printf_LCD("\r\n set_pos: %d", set_pos);
	ToA72_SetCameraPos(set_pos);//��A72��������ͷԤ��λ
	delay_ms(2500);			//�ȴ�����ͷ��Ԥ��λ
	if (Switch_TFLight == 1) {
		ToA72_RecgTrafficLight(Mark);		//��A72����ʶ��
	}	
	else{
		delay_ms(500);
	}
}


/*
���ܣ�ʶ���ά��
*/
void Identify_QRCode(void){
	if(Marker_InitStruct.CODE.Recognition_Num < CODE_Recognition_Par_Num){	
		if (Switch_QR1 == 1) {
			
			if (Marker_InitStruct.CODE.Recognition_Par[Marker_InitStruct.CODE.Recognition_Num].Correct_track== ENABLE) {	//����·��
				correct_trackBack(60, 40, 0, 0);
				go_forward(60, Mylib.go_value + 30);
			}
			//printf_LCD("\r\n set_pos: %d", Marker_InitStruct.CODE.Recognition_Par[Marker_InitStruct.CODE.Recognition_Num].SetCameraPos);
			ToA72_SetCameraPos(Marker_InitStruct.CODE.Recognition_Par[Marker_InitStruct.CODE.Recognition_Num].SetCameraPos);//��A72��������ͷԤ��λ
			//Delay_ms_02(5000);
			delay_ms(2500);
			ToA72_RecgQRCode(Marker_InitStruct.CODE.Recognition_Num+1);//ʶ���ά��ָ��
			memcpy(Marker_InitStruct.CODE.Recognition_Par[Marker_InitStruct.CODE.Recognition_Num].Rec_Data, QRCodeResult, 20);//��ʶ�𵽵����ݱ�������
			
			Marker_InitStruct.CODE.Recognition_Num+=1;	
			
			{//��ʾʶ�𵽵����ݵ���С��Һ����Ļ��
				u8 Debug_Temp[sizeof(Marker_InitStruct.CODE.Recognition_Par[0].Rec_Data)*3];
				u8 i=0;
				for(i=0;i<sizeof(Marker_InitStruct.CODE.Recognition_Par[0].Rec_Data);i++){			
					sprintf((char *)Debug_Temp+i*3, "%x", Marker_InitStruct.CODE.Recognition_Par[0].Rec_Data[i]);
					Debug_Temp[i*3-1]=' ';
				}

				Send_InfoData_To_Fifo(Debug_Temp, sizeof(Debug_Temp));
				
				delay_ms(100);
			}
			
		}
	}
	else{
		
		{//ʶ�����
				char Debug_Temp[]="CODE_Recognition_Over\n";
				Send_InfoData_To_Fifo((u8 *)Debug_Temp,strlen(Debug_Temp));
				delay_ms(100);
		}
	}
	
}

