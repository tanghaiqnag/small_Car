#ifndef __INIT_MARKER_H
#define __INIT_MARKER_H
#include "stm32f4xx.h"
#include "sys.h"

#endif

