#include "stm32f4xx.h"
#include "gpio.h"
#include "ultrasonic.h"
#include "delay.h"
#include "cba.h"
#include "canp_hostcom.h"
#include "stdio.h"
#include "tba.h"

float Ultrasonic_Value = 0;
uint32_t Ultrasonic_Num=0;						// ����ֵ
uint16_t dis =0 ;

//void Ultrasonic_Port()
//{
//	GPIO_InitTypeDef GPIO_InitStructure;

//	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB,ENABLE);
//	

//	//GPIO_PinAFConfig(GPIOB,GPIO_PinSource4,GPIO_AF_SWJ);
//	//GPIO_PinAFConfig(GPIOB,GPIO_PinSource3,GPIO_AF_SWJ);
//	//GPIO_PinAFConfig(GPIOA,GPIO_PinSource15,GPIO_AF_SWJ);
//	GPIO_PinAFConfig(GPIOA,GPIO_PinSource14,GPIO_AF_SWJ);
//	GPIO_PinAFConfig(GPIOA,GPIO_PinSource13,GPIO_AF_SWJ);
//	
//	//GPIOA15---INC--RX
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  //ͨ�����
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //������� 
//	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;   //����
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
//	GPIO_Init(GPIOA,&GPIO_InitStructure);
//	
//	//GPIOB4---INT0--TX
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;   //���� 
//	GPIO_Init(GPIOB,&GPIO_InitStructure);
//	
//}


void Ultrasonic_TIM(uint16_t arr,uint16_t psc)
{
	//GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
	
	TIM_InitStructure.TIM_Period = arr;
	TIM_InitStructure.TIM_Prescaler = psc;
	TIM_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
//�˲����Ի�����ʱ����Ч
//	TIM_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_InitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM6,&TIM_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = TIM6_DAC_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 8;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM6, DISABLE);
}

void Ultrasonic_EXTI()
{
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
//	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB,EXTI_PinSource4);
	SYSCFG_EXTILineConfig(EXTI_PortSource_GPIO_Port,EXTI_PinSource_Num);
//	EXTI_InitStructure.EXTI_Line = EXTI_Line4;
	EXTI_InitStructure.EXTI_Line = EXTI_Line_Num;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
//	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI_Num_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 7;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void Ultrasonic_Init()
{
//	Ultrasonic_Port();
	Ultrasonic_TIM(9,83);
	Ultrasonic_EXTI();
}

//���������
void Ultrasonic_Ranging()
{
  INC_OFF;           
	delay_us(3);
  INC_ON;

	TIM_Cmd(TIM6,ENABLE);
	//EXTI_ClearITPendingBit(EXTI_Line4);	
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
	
  Ultrasonic_Num  = 0;			 // ��ʱ������

	delay_ms(30);			 //�ȴ�һ��ʱ�䣬�ȴ����ͳ����������ź�
	INC_OFF;
	delay_ms(5);
}

void TIM6_DAC_IRQHandler()
{
	if(TIM_GetITStatus(TIM6,TIM_IT_Update) == SET)
	{
		Ultrasonic_Num++;
		
	}
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
}


void EXTI_IRQHandler(void)
{
//	if(EXTI_GetITStatus(EXTI_Line4) == SET)
	if(EXTI_GetITStatus(EXTI_Line_Num) == SET)
	{
//		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == RESET)
		if(INT0 == 0)
		{	
			TIM_Cmd(TIM6,DISABLE);
			Ultrasonic_Value = Ultrasonic_Num;
			Ultrasonic_Value =(float)Ultrasonic_Value*1.72f-20;       // ������붨ʱ10us��S=Vt/2����2��������
			dis = (uint16_t) Ultrasonic_Value;
		}
//		EXTI_ClearITPendingBit(EXTI_Line4);
		EXTI_ClearITPendingBit(EXTI_Line_Num);
	}
}
char uf[10];
uint16_t Ultrasonic_Measure(void)
{
	uint16_t Distance[10] = {0};
	uint16_t Distance_Temp = 0;
	uint8_t i;
	uint8_t j = 0;
	uint8_t Measure_Num = 8;
	uint16_t Max_error = 0;
	uint8_t Max_error_flag = 0;
	uint16_t Range = 0;
	uint16_t adf = 0;
	Ultrasonic_Ranging();
	delay_ms(100);
	for (i = 0; i < Measure_Num; i++) {
		Ultrasonic_Ranging();
		Distance[i] = dis;		//��¼�ɼ���
		sprintf(uf, "%d", dis);
		Send_InfoData_To_Fifo((uint8_t *)uf, 5);
		Send_InfoData_To_Fifo((uint8_t *)"\n", 2);
		delay_ms(100);
		dis = 0;
		adf = Distance[0];
	}
	dis = 0;	//��0
	for (i = 0; i < Measure_Num - 1; i++)	{	//����
		for (j = 0; j < Measure_Num - 1; j++) { 
			if (Distance[j] > Distance[j + 1]) {
				Distance_Temp = Distance[j];
				Distance[j] = Distance[j + 1];
				Distance[j + 1] = Distance_Temp;
			}
		}
	}
	//�ҳ������
	Max_error = Distance[1] - Distance[0];
	for (i = 1; i < Measure_Num - 1; i++) {
		if (Max_error < Distance[i + 1] - Distance[i]) {
			Max_error = Distance[i + 1] - Distance[i];	//�����
			Max_error_flag = i;				//���������ֵ��λ��
		}
	}
	if (Max_error >= 10) {
		//ȡ������ֵ
		if (Max_error_flag + 1 > (Measure_Num + 1) / 2) {
			for (i = 0; i <= Max_error_flag; i++) 
				Range += Distance[i];
			Range /= (Max_error_flag + 1);
		}
		else {
			for (i = Max_error_flag + 1; i < Measure_Num; i++)
				Range += Distance[i];
			Range /= (Measure_Num - Max_error_flag - 1);		//ȥƽ��
		}
//		return Range;
		printf_LCD((char *)"zuizhong:%d", adf);
		return adf;										//���ص�һ��ֵ
	}
	else {
		Range = (Distance[4] + Distance[5]) / 2;
	
		printf_LCD((char *)"zuizhong:%d", Range);
		return Range;
	}
	
}




