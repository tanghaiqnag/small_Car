#include "A72.h"
#include "crc24.h"
#include "Mark_Fun.h"
#include "Mylib.h"
#include "HS_Send.h"
uint8_t TaskSwitch = 0xFF;
uint8_t AGVDir = 0x0;

uint8_t TFTShapeResult[32];
uint8_t TFTPlateResult[32];
uint8_t TFTQRCodeResult[32] = {0};
uint8_t AlarmOpenCode[36]={0};
uint8_t RFIDRes[16];
uint8_t OpenMVRes[32];
uint8_t QRCodeResult[32];
uint8_t TrafficLightResult;
uint8_t JinTaiResult[32];
uint8_t OutputBuf[48];
uint8_t LightGear;
uint8_t Floor;


void SendDataWithAck(uint8_t * data, uint8_t len);

uint8_t PackCmd(uint8_t * buf, uint8_t cmd, uint8_t * arg, uint8_t len);
uint8_t handleRecv(uint8_t * buf);

uint8_t handleRFID(uint8_t * data);				//�ش�����rfid��Ч��Ϣ
uint8_t handleOpenMV(uint8_t * data);			//�ش�����OpenMV��Ч��Ϣ
uint8_t handleTFLight(uint8_t * data);		//�ش����潻ͨ��ʶ��������������ͨ��
uint8_t handleTFT(uint8_t * data);				//�ش�����TFT���(��ʱû����)
uint8_t handleQR(uint8_t * data);					//�ش������ά����Ϣ(��ʱû����)
uint8_t handleJintai(uint8_t * data);			//�ش����澲̬��Ϣ(��ʱû����)
uint8_t handleOpenCode(uint8_t * data);		//�ش�������̨��Ϣ
uint8_t handleAck(uint8_t * data);				//�ش�����rfid��Ч��Ϣ
uint8_t handleFloor(uint8_t * data);			//�ش�����ͣ��������Ϣ
uint8_t handleLightGear(uint8_t * data);	//�ش�����·�Ƶ�λ��Ϣ



TFTDataRec TFTData = {0};

void go(uint8_t speed, uint16_t mp);
void back(uint8_t speed, uint16_t mp);


void ToA72_SendData(uint8_t cmd,uint8_t data,uint8_t Return_flag)              //����һ���ֽ����ݸ���׿
{
	uint8_t arg[1] = {data};
	uint8_t len = PackCmd(OutputBuf, cmd, arg, 1);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	delay_ms(300);
	if(Return_flag==1)
	{
		//uint16_t TimeOut = 2500;
		uint16_t TimeOut = 250;
		uint8_t r = 0;
		while (--TimeOut) {
			if (Wifi_Rx_flag) {
				delay_ms(30);
				r = handleRecv(Wifi_Rx_Buf);
				Wifi_Rx_flag = 0;
			}
			if (r == 1) break;
			delay_ms(1);
		}
		if (r == 1) {
			Send_InfoData_To_Fifo(RFIDRes, 16);
			Send_InfoData_To_Fifo("\n", 2);
		}
		if (TimeOut == 0) {
			Send_InfoData_To_Fifo("TO\n", 4);
		}
		delay_ms(300);
	}
}


void ToA72_SendRFIDData(void)						//���ʹ�RFID����ȡ�������ݵ�A72
{
	uint8_t len = PackCmd(OutputBuf, 0x01, RXRFID, 17);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	//uint16_t TimeOut = 2500;
	uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag) {
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
	if (r == 1) {
		Send_InfoData_To_Fifo(RFIDRes, 16);
		Send_InfoData_To_Fifo("\n", 2);
	}
	if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}
	delay_ms(300);
}

void ToA72_SendLightGrade(uint8_t grade)			//���͹�Դ��λ
{
	
	uint8_t arg[1] = {grade};
	uint8_t len = PackCmd(OutputBuf, 0x02, arg, 1);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);//��������
	delay_ms(300);
}



void ToA72_SendASRRes(uint8_t res)                            //��������ʶ����
{
	uint8_t arg[1] = {res};
	uint8_t len = PackCmd(OutputBuf, 0x03, arg, 1);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	delay_ms(300);
}


void ToA72_SendOpenMVRes(uint8_t * src, uint8_t srcLen)    //����openMVʶ����
{
	uint8_t len = PackCmd(OutputBuf, 0x04, src, srcLen);
	delay_ms(100);
	SendDataWithAck(OutputBuf, len);
	//uint16_t TimeOut = 5000;
	uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag){
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
	if (r == 1) {
		Send_InfoData_To_Fifo(OpenMVRes, 16);
		Send_InfoData_To_Fifo("\n", 2);
	}
	if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}
	delay_ms(300);
}

void ToA72_SetCameraPos(uint8_t posID)                        //��������ͷλ��
{
	uint8_t arg[1] = {posID};
	uint8_t len = PackCmd(OutputBuf, 0x05, arg, 1);
	printf_LCD("\r\n set_pos: %d", arg[0]);
	delay_ms(500);
	SendDataWithAck(OutputBuf, len);
	delay_ms(300);
}

void ToA72_RecgTFT(uint8_t tftID)                             //ʶ��TFT����
{
	uint8_t arg[1] = {tftID};
	uint8_t len = PackCmd(OutputBuf, 0x06, arg, 1);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	uint16_t TimeOut = 30000;
	//uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag) {
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
	if (r == 1) {
		Send_InfoData_To_Fifo(TFTShapeResult, 8);
		Send_InfoData_To_Fifo("\n", 2);
		delay_ms(500);
		Send_InfoData_To_Fifo(TFTPlateResult, 8);
		Send_InfoData_To_Fifo("\n", 2);
	}
	if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}
	delay_ms(300);
}

static uint8_t Traffic_Mark;
void ToA72_RecgTrafficLight(uint8_t Mark)                     //ʶ��ͨ��
{
	Traffic_Mark = Mark;
	uint8_t len = PackCmd(OutputBuf, 0x07, NULL, 0);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	uint16_t TimeOut = 20000;
	//uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag) {
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
    if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}
	delay_ms(300);
}

void ToA72_RecgQRCode(uint8_t qrID)                       //ʶ���ά��
{
	uint8_t arg[1] = {qrID};
	uint8_t len = PackCmd(OutputBuf, 0x08, arg, 1);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	//uint16_t TimeOut = 25000;
	uint16_t TimeOut = 10000;
	//uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag) {
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
	
	if (r == 1) {
		Send_InfoData_To_Fifo(QRCodeResult, 8);
		Send_InfoData_To_Fifo("\n", 2);
	}
	if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}
	delay_ms(300);
}

void ToA72_RecgJintai(uint8_t jtID)
{
  uint8_t arg[1] = {jtID};
	uint8_t len = PackCmd(OutputBuf, 0x09, arg, 1);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	//uint16_t TimeOut = 30000;
	uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag) {
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
	if (r == 1) {
		Send_InfoData_To_Fifo(JinTaiResult, 8);
		Send_InfoData_To_Fifo("\n", 2);
	}
	if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}
	delay_ms(300);

}

void ToA72_PrcoOpenCode(void)
{
	uint8_t len = PackCmd(OutputBuf, 0x0A, NULL, 0);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);
	//uint16_t TimeOut = 7000;
	uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag) {
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
	if (r == 1) {
		Send_InfoData_To_Fifo("ProcDone", 8);
		Send_InfoData_To_Fifo("\n", 2);
	}
	if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}

	delay_ms(300);
}

void ToA72_SendRange(uint16_t Range)			   //���Ͳ��
{
	uint8_t arg[2] = {0};
	arg[0]= Range>>8;
	arg[1]= Range;
	uint8_t len = PackCmd(OutputBuf, 0x0C, arg, 2);
	delay_ms(300);
	SendDataWithAck(OutputBuf, len);//��������
	//uint16_t TimeOut = 5000;
	uint16_t TimeOut = 250;
	uint8_t r = 0;
	while (--TimeOut) {
		if (Wifi_Rx_flag){
			delay_ms(30);
			r = handleRecv(Wifi_Rx_Buf);
			Wifi_Rx_flag = 0;
		}
		if (r == 1) break;
		delay_ms(1);
	}
	if (r == 1) {
		Send_InfoData_To_Fifo("\n", 2);
	}
	if (TimeOut == 0) {
		Send_InfoData_To_Fifo("TO\n", 4);
	}
	delay_ms(300);
}
/*
���ܣ����ذ�׿������ɵĴӳ�OpenMV����
*/
uint8_t handleRecv(uint8_t * buf)
{
//	printf_LCD("0x%06x\r\n", *((unsigned long*)buf));
	if (buf[0] == 0x55 && buf[1] == 0x5A) {
		switch (buf[2]) {
			case 0x01:
				return handleFloor(buf + 3);
			case 0x04:
				return handleOpenMV(buf + 3);
			case 0x06:
				switch(buf[3]){
					case 0x78://��ά��
					{
						TFTData.QRCode.DataLen[TFTData.QRCode.DataNum] = buf[4];				 
						//memcpy(TFTData.QRCode.Data[TFTData.QRCode.DataNum], buf+5, buf[4]); //��������				
						TFTData.QRCode.DataNum += 1;
					}
					break;
					case 0x01://ͼ��
					{
						uint8_t i = 0;
						for(i=0;i<5;i++){
							memcpy(TFTData.Shape.Data[TFTData.Shape.DataNum][i], buf+5+i*8, 8); //��������		
						}		
						TFTData.Shape.DataNum += 1;
//						printf_LCD("\n");
//						for(int a=0;a<5;a++)
//						{
//							for(int b=0;b<8;b++)
//							{
//								printf_LCD("%d",TFTData.Shape.Data[TFTData.Shape.DataNum][a][b]);
//							}
//							printf_LCD("\n");
//						}
					}
					break;
					case 0x02://����
						memcpy(TFTData.plate.Data[TFTData.plate.DataNum], buf+5, 6); //��������		
						TFTData.plate.DataNum += 1;
						break;
					case 0x03://��ͨ��־
						TFTData.TrafficSign.Data[TFTData.TrafficSign.DataNum]=buf[5]; //��������
						TFTData.TrafficSign.DataNum += 1;
						break;
					case 0x04://���˿��ּ��
						TFTData.Pedestrian.Data[TFTData.Pedestrian.DataNum]=buf[5]; 
						printf_LCD("%d\r\n", TFTData.Pedestrian.Data[TFTData.Pedestrian.DataNum]);
						TFTData.Pedestrian.DataNum += 1;
						break;
					case 0x05://�ı�ʶ��
						TFTData.Text.Data[TFTData.Text.DataNum]=buf[5]; //��������
						printf_LCD("%d\r\n", TFTData.Text.Data[TFTData.Text.DataNum]);
						TFTData.Text.DataNum += 1;
						break;
					case 0x55:
						return 1;
						break;
//				return handleTFT(buf + 3);
				}
				
				break;
			case 0x07:
				return handleTFLight(buf + 3);
			case 0x08:      //��ά�����ݴ洢
			{
//				uint8_t i = 0;
//				CrcFun(buf+5,buf[4]);
//				for(i=0;i<6;i++){
//					memcpy(Marker_InitStruct.ALARM.Data + i*6,HwArr,6);
//				}
//				
//				printf_LCD("\r\n");
//				
//				for(i=0;i<6;i++){
//					printf_LCD("0x%2x",*(Marker_InitStruct.ALARM.Data+i));
//				}
//				
//				printf_LCD("\r\nCRCOver");
				
			}
				return handleQR(buf + 3);
			case 0x09:
				return handleJintai(buf + 3);
			case 0x0A:
				return handleOpenCode(buf + 3);
			case 0x20:
				go(buf[3], buf[4] | (buf[5] << 8));
				break;
			case 0x30:
				back(buf[3], buf[4] | (buf[5] << 8));
				break;
			case 0x40:
				traffic_request(Traffic_Mark);
				break;
			case 0x50:
				printf_LCD("\n");
				TFT_pageUp('A');
				break;
			case 0x55:
				TFT_pageUp('B');
				break;
			case 0x77:
				return handleAck(buf + 3);
				break;
			case 0x0C:
				return handleLightGear(buf + 3);
			case 0x0D:
				return handleFloor(buf + 3);
		}
		buf[2] = 0;
	}
	return 0;
}

uint8_t handleFloor(uint8_t * data)
{
	if (data[0] == 0x01) {
		Floor=data[1];
		return 1;
	}
	return 0;
}
uint8_t handleLightGear(uint8_t * data)
{
	if (data[0] == 0x01) {
		LightGear=data[1];
		printf_LCD((char *)"%d",LightGear);
		return 1;
	}
	return 0;
}

uint8_t handleRFID(uint8_t * data)			
{
	if (data[0] == 0x01) {
		memcpy(RFIDRes, data + 2, data[1]);
		return 1;
	}
	return 0;
}

uint8_t handleOpenMV(uint8_t * data)
{
	if (data[0] == 0x01) {
		memcpy(OpenMVRes, data + 2, data[1]);
		printf_LCD("%s");
		return 1;
	}
	return 0;
}

uint8_t handleTFLight(uint8_t * data)
{
	if (data[0] == 0x01) {
		TrafficLightResult = data[1];
		traffic_result(Traffic_Mark, TrafficLightResult);
		return 1;
	}
	return 0;
}

uint8_t handleTFT(uint8_t * data)
{
	if (data[0] == 0x01) {
		memcpy(TFTShapeResult, data + 2, data[1]);
	} else if (data[0] == 0x02) {
		memcpy(TFTPlateResult, data + 2, data[1]);
	} else if (data[0] == 0x03) {
		memcpy(TFTQRCodeResult, data + 2, data[1]);
	} else if (data[0] == 0x05) {
		return 1;
	}
	return 0;
}

uint8_t handleQR(uint8_t * data)
{
	if (data[0] == 0x01) {
		memcpy(QRCodeResult, data + 2, data[1]);
		for(int a=0;a<3;a++)
			printf_LCD((char *)"%d\n",QRCodeResult[a]);
		return 1;
	}
	return 0;
}

uint8_t handleJintai(uint8_t * data)
{
	if (data[0] == 0x01) {
		memcpy(JinTaiResult, data + 2, data[1]);
		return 1;
	}
	return 0;

}

uint8_t handleOpenCode(uint8_t * data)//���̨�����룬data�ǽ��ܵ�����������ݣ�������36λ
{
	if (data[0] == 0x01) {
		memcpy(AlarmOpenCode, data + 2, 36);
		return 1;
	}
	return 0;
}


uint8_t handleAck(uint8_t * data)
{
	if (data[0] == 0x01) {
		return 6;
	}
	return 0;
}


void handleSwitch(uint8_t * data)
{
	TaskSwitch = data[1];
	ack(data, 0, 2);
}

void handleAgvdir(uint8_t * data)
{
	AGVDir = data[1];
	if (AGVDir == 0) AGVDir = 1;
	ack(data, 0, 2);
}

void ack(uint8_t * data, uint8_t startIndex, uint8_t len)
{
	uint16_t checkSum = 0;
	OutputBuf[0] = 0x55;
	OutputBuf[1] = 0xA5;
	for (uint8_t i = startIndex; i < len; i++)
		checkSum += ((uint16_t)data[i]) & 0x00FF;
	OutputBuf[2] = 0x80;
	OutputBuf[3] = (uint8_t)(checkSum % 256);
	OutputBuf[4] = 0;
	OutputBuf[5] = 0;
	OutputBuf[6] = 0;
	OutputBuf[7] = 0xBB;
	sendData(OutputBuf, 8);
}



uint8_t PackCmd(uint8_t * buf, uint8_t cmd, uint8_t * arg, uint8_t len)
{
	uint16_t checkSum = cmd;
	OutputBuf[0] = 0x55;
	OutputBuf[1] = 0x5A;
	for (uint8_t  i = 0; i < len; i++)
		checkSum += ((uint16_t)arg[i]) & 0x00FF;
	OutputBuf[2] = cmd;
	OutputBuf[3] = checkSum % 256;
	OutputBuf[4] = len;
	for (uint8_t i = 0; i < len; i++)
		OutputBuf[5 + i] = arg[i];
	return 5 + len;
}

void sendData(uint8_t * data, uint8_t len)
{
	Send_WifiData_To_Fifo(data, len);
	delay_ms(10);
	UartA72_TxClear();
	UartA72_TxAddStr(data, len);
	UartA72_TxStart();
}

void SendDataWithAck(uint8_t * data, uint8_t len)
{
	uint8_t i;
	for (i = 0; i < 1; i++) {
		uint8_t r = 0;
		uint16_t timeOut = 1000; 
		Send_WifiData_To_Fifo(data, len);
		delay_ms(10);
		UartA72_TxClear();
		UartA72_TxAddStr(data, len);
		UartA72_TxStart();
		while (--timeOut) {
			if (Wifi_Rx_flag) {
				delay_ms(30);
				r = handleRecv(Wifi_Rx_Buf);
				Wifi_Rx_flag = 0;
			}
			if (r == 6) return;
			delay_ms(1);
		}
	}
}


void go(uint8_t speed, uint16_t mp)
{
	Roadway_mp_syn();	//����ͬ��
	Stop_Flag = 0; Go_Flag = 1; wheel_L_Flag = 0;wheel_R_Flag = 0;wheel_Nav_Flag = 0;
	Back_Flag = 0; Track_Flag = 0;
	temp_MP = mp;
	Car_Spend = speed;
	Control(Car_Spend ,Car_Spend);
}

void back(uint8_t speed, uint16_t mp)
{
	Roadway_mp_syn();	//����ͬ��
	Stop_Flag = 0; Go_Flag = 0; wheel_L_Flag = 0;wheel_R_Flag = 0;wheel_Nav_Flag = 0;
	Back_Flag = 1; Track_Flag = 0;
	temp_MP = mp;
	Car_Spend = speed;
	Control(-Car_Spend ,-Car_Spend);
}
