#include "HS_Rec_Data_Pro.h"
#include "delay.h"
#include <string.h>
#include "Digital_track.h"
#include "Mylib.h"
#include "Mark_Fun.h"
#include "A72.h"
int zig_rec_flag=0;
uint8_t chepai[6]={0};
uint8_t buf[16]={0};
//MasterCar_And_SlaveCar_Transmit
/*
���ܣ����ӳ�ͨѶ�Խ��յ������ݽ��д���
���룺��������ӿ�
*/
void Pro_HS_Data_Run(HS_Data_Typ *Data_In){
	switch(Data_In->Fun_Data_Num){
		case Stop:
			break;
		case Go:
			memcpy(buf,Data_In->Data,Data_In->Fun_Data_Len);
			printf_LCD((char *)"%s",buf);
			printf_LCD((char *)"start");
			//Start_Digital_Track_Table(1,true,false);
			break;
		case Back:
			printf_LCD("back");
			break;
		case TurnLeft:
			break;
		case TurnRight:
			break;
		case Track:
			break;
		case CodeDisk_Init:
			break;
		case TurnLeft_CodeDisk:
			break;
		case TurnRight_CodeDisk:
			break;
		case Set_RorL_LED:
			break;
		case Set_BEEP:
			break;
		case TFT_Up:
			break;
		case TFT_Down:
			break;
		case Light_Plus_One:
			break;
		case Light_Plus_Two:
			break;
		case Light_Plus_Three:
			break;
		case Start:
			//memcpy(buf,Data_In->Data,Data_In->Fun_Data_Len);
			dixin = Data_In->Data[0];
			printf_LCD((char *)"start:%d",dixin);
			Start_Digital_Track_Table(7,true,true);

			break;
		case Save_Task_Head:
			break;
		case Save_Task_Table:
			break;
		case Save_Distance_Dat:
			break;
		case Save_Light_Value:
			break;
		case Save_Alarm_Data:
			break;
		case Save_Shape_Data:
			break;
		case Save_Plate_Date:
			printf_LCD((char *)"\nchepai:\n");
			
			memcpy(Marker_InitStruct.GATE.Data,Data_In->Data,Data_In->Fun_Data_Len);
			printf_LCD((char *)"%s",Marker_InitStruct.GATE.Data);
			printf_LCD((char *)"start");
			Start_Digital_Track_Table(1,true,false);
			break;
	}
}
