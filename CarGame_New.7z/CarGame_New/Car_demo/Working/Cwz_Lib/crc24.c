
#include <stdio.h>
#include <crc24.h>
#include <string.h>
unsigned long crc = 0x00555555;
unsigned long Polynomial = 0x00065B; //����ʽ


unsigned char zifuchuan[20];
unsigned char now[2]={'G','2'};
unsigned char ruku[2];

void luxianbianzhi(unsigned char *luxian)
{
//	unsigned char luxian[30]={4};
	luxian[0]=4;
	unsigned char liebiao[7][2]={0};
	unsigned char future[2];
	unsigned char rukuwei[2];
	unsigned char rukudian[2];
	unsigned char renwudian[2]={'D','4'};
	unsigned char rukufangxiang;	
	unsigned char i,k=0;
	unsigned char l;
	l=1;
//	printf("shuruzifuchuan:");
// 	scanf("%s",zifuchuan);
// 	printf("\n%s",zifuchuan);
 	for(i=0;i<zifuchuan[i]!='\0';i++)
 	{
 		if((zifuchuan[i]<='G'&&zifuchuan[i]>='A')||(zifuchuan[i]<='z'&&zifuchuan[i]>='a'))
 		{
 			if(zifuchuan[i+1]<='7'&&zifuchuan[i+1]>='0')
 			{
 				liebiao[k][0]=zifuchuan[i];
 				liebiao[k][1]=zifuchuan[i+1];
// 				printf("\n%d:%c%c",k,liebiao[k][0],liebiao[k][1]);
 				k++;
			 }
		}
	}
	memcpy(rukudian,liebiao[k-1],2);
//	printf("\nrukudian:%c%c",rukudian[0],rukudian[1]);
	{			//Ѱ������ 
		if(rukudian[0]=='G')
		{
			rukuwei[0]='F';
			rukuwei[1]=rukudian[1];
			rukufangxiang=4; 
		}
		else if(rukudian[0]=='A')
		{
			rukuwei[0]='F';
			rukuwei[1]=rukudian[1];
			rukufangxiang=2; 
		}
		else if(rukudian[1]=='1')
		{
			rukuwei[0]=rukudian[0];
			rukuwei[1]='2';
			rukufangxiang=3; 
		}
		else if(rukudian[1]=='7')
		{
			rukuwei[0]=rukudian[0];
			rukuwei[1]='6';
			rukufangxiang=1; 
		}
	}  
//	printf("\nrukuwei:%c%c",rukuwei[0],rukuwei[1]);
	{
		liebiao[k-1][0]=rukuwei[0];
 		liebiao[k-1][1]=rukuwei[1];
	}
//	printf("\n\n\n%d",);
	for(i=0;i<k;i++)
	{
		memcpy(future,liebiao[i],2);
		if(now[0]==renwudian[0]&&now[1]==renwudian[1])
		{
				luxian[l]=14;
				l++;
		}
		while(now[1]!=future[1])
		{
			if(now[1]>future[1])
			{
				luxian[l]=1;
				l++;
				if(now[1]=='2'||now[1]=='7')
				{
					now[1]=now[1]-1;		
				}
				else
				{
					now[1]=now[1]-2;
				}
			}
			else
			{
				luxian[l]=3;
				l++;
				if(now[1]=='1'||now[1]=='6')
				{
					now[1]=now[1]+1;		
				}
				else
				{
					now[1]=now[1]+2;
				}	
			}
		}
		
		
		while(now[0]!=future[0])
		{
			
			if(now[0]>future[0])
			{
				luxian[l]=4;
				l++;
				if(now[0]=='G'||now[0]=='B')
				{
					now[0]=now[0]-1;		
				}
				else
				{
					now[0]=now[0]-2;
				}
			}
			else
			{
				luxian[l]=2;
				l++;
				if(now[0]=='A'||now[0]=='F')
				{
					now[0]=now[0]+1;		
				}
				else
				{
					now[0]=now[0]+2;
				}
			} 
		}
	}
	luxian[l]=rukufangxiang;
	l++;
	luxian[l]='\0';	
}




void chekuxunzhi(unsigned char *luxian)
{
//	unsigned char luxian[30]={4};
	unsigned char future[2];
	unsigned char rukuwei[2];
	unsigned char rukufangxiang;	
	unsigned char l;
	l=0;
//	printf("shuruzifuchuan:");
// 	scanf("%s",zifuchuan);
// 	printf("\n%s",zifuchuan);
//	printf("\nrukudian:%c%c",rukudian[0],rukudian[1]);
	{			//Ѱ������ 
		if(ruku[0]=='G')
		{
			rukuwei[0]='F';
			rukuwei[1]=ruku[1];
			rukufangxiang=4; 
		}
		else if(ruku[0]=='A')
		{
			rukuwei[0]='B';
			rukuwei[1]=ruku[1];
			rukufangxiang=2; 
		}
		else if(ruku[1]=='1')
		{
			rukuwei[0]=ruku[0];
			rukuwei[1]='2';
			rukufangxiang=3; 
		}
		else if(ruku[1]=='7')
		{
			rukuwei[0]=ruku[0];
			rukuwei[1]='6';
			rukufangxiang=1; 
		}
	}  
//	printf("\nrukuwei:%c%c",rukuwei[0],rukuwei[1]);
	{
		future[0]=rukuwei[0];
 		future[1]=rukuwei[1];
	}
//	printf("\n\n\n%d",);
		while(now[1]!=future[1])
		{
			if(now[1]>future[1])
			{
				luxian[l]=1;
				l++;
				if(now[1]=='2'||now[1]=='7')
				{
					now[1]=now[1]-1;		
				}
				else
				{
					now[1]=now[1]-2;
				}
			}
			else
			{
				luxian[l]=3;
				l++;
				if(now[1]=='1'||now[1]=='6')
				{
					now[1]=now[1]+1;		
				}
				else
				{
					now[1]=now[1]+2;
				}	
			}
		}
		
		
		while(now[0]!=future[0])
		{
			
			if(now[0]>future[0])
			{
				luxian[l]=4;
				l++;
				if(now[0]=='G'||now[0]=='B')
				{
					now[0]=now[0]-1;		
				}
				else
				{
					now[0]=now[0]-2;
				}
			}
			else
			{
				luxian[l]=2;
				l++;
				if(now[0]=='A'||now[0]=='F')
				{
					now[0]=now[0]+1;		
				}
				else
				{
					now[0]=now[0]+2;
				}
			} 
		}
//		printf("\n%d:%c%c",i,now[0],now[1]);		
		
//		printf("\n%d:%c%c",i,now[0],now[1]);
//		printf("\n%d:%c%c",i,future[0],future[1]);	
	luxian[l]=rukufangxiang;
	l++;
	luxian[l]='\0';	
//	printf("\nluxian:");
//	for(i=0;i<10;i++)
//	{
//		printf("%d\t",luxian[i]);		
//	}
}




void tiquqizuobiaodian(unsigned char liebiao[7][2])
{
	unsigned char i,k;
 	for(i=0;i<zifuchuan[i]!='\0';i++)
 	{
 		if((zifuchuan[i]<='G'&&zifuchuan[i]>='A')||(zifuchuan[i]<='z'&&zifuchuan[i]>='a'))
 		{
 			if(zifuchuan[i+1]<='7'&&zifuchuan[i+1]>='0')
 			{
 				liebiao[k][0]=zifuchuan[i];
 				liebiao[k][1]=zifuchuan[i+1];
// 				printf("\n%d:%c%c",k,liebiao[k][0],liebiao[k][1]);
 				k++;
			 }
		}
	}
}


void luxianjiehe(char *s1,char *s2)
{
	strcat(s1,s2);
}

























































//���ݷ�ת
unsigned long DataTran(unsigned long Arg, unsigned char ArgBNum){
    unsigned long RecArg = 0;
    unsigned char i = 0;
    unsigned long LSB = 0;

    for(i=0;i<ArgBNum;i++){
        if(Arg & (1 << i)){
            LSB = 1;
        }
        else{
            LSB = 0;
        }
	    // printf("%x  ",LSB);
        RecArg |= (unsigned long)(LSB << ((unsigned long)(ArgBNum-1) - i));
    }
    return RecArg;
}
//CRC ����
void Crc_process(unsigned char data)
{
	unsigned char j;
	unsigned char MSB;
    

	crc = crc ^ (data << 16); 					//24λ�еĸ�8λ			
	for(j=0;j<8;j++)
	{
		MSB = !!(crc & 0x800000);				//�Ƿǵ���
		crc <<= 1;
		if (MSB)
		{
			crc = crc ^ Polynomial;
		}
	}
	crc &= 0xFFFFFF;         
}

unsigned char HwArr[6];
void CrcFun(unsigned char *Arr,unsigned char ArrLen){
	unsigned char i = 0;
	unsigned char *date = Arr;
	
	for(i=0;i<ArrLen;i++)
	{   //���յ���ÿ�����ݶ���Ҫ��λ��ת    
		date[i] = DataTran(date[i],8);
		Crc_process(date[i]);   
        // printf("0x%2x\n",crc); 
	}
	
	//����0xF1FA62
	crc = DataTran(crc, 24);
//    printf("0x%06X\n",crc);

	{
//		int i;
		sprintf(HwArr,"%06X",crc);
//		for(i=0;i<6;i++)
//		{
//			printf("0x%x\n",HwArr[i]);
//		}
		
	}
}








//int main()
//{
//	unsigned char i = 0;
//	unsigned char date[10]={0x42,0x4A,0x31,0x30};
//	// unsigned char date[10]={0x47, 0x44, 0x53, 0x32, 0x30};
//	CrcFun(date,4);
////	Polynomial = DataTran(Polynomial, 24);
//	// for(i=0;i<sizeof(date);i++)
//	// {       
//	// 	date[i] = DataTran(date[i],8);
//	// 	Crc_process(date[i]);   
//    //     // printf("0x%2x\n",crc); 
//	// }
//	// //����0xF1FA62
//	// crc = DataTran(crc, 24);
//    // printf("0x%06X\n",crc);

//	// {
//	// 	char str[6];
//	// 	int i;
//	// 	sprintf(str,"%06X",crc);
//	// 	for(i=0;i<6;i++)
//	// 	{
//	// 		printf("0x%x\n",str[i]);
//	// 	}
//		
//	// }
//}

