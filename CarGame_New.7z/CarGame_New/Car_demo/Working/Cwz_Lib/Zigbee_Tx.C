#include "Zigbee_Tx.H"
#include "stdio.H"
#include "string.H"
#include "canp_hostcom.h"

#define OFF_Int_Zigbee_Send										Send_Flag=false;	//�رշ���
#define ON_Int_Zigbee_Send										Send_Flag=true;		//��������
#define Zigbee_Send_Data_Base_Api							Send_ZigbeeData_To_Fifo		//����zigbee����;


#define Data_Num_Max 10

typedef struct 
{
	volatile uint8_t Data[Data_Num_Max][8];
	volatile uint8_t Data_Num;
}Send_Typ;

Send_Typ Send={
	.Data={0},
	.Data_Num=0,
};

void Zigbee_Send_Data(uint8_t* Data) {
	if (Send.Data_Num < Data_Num_Max) {
		memcpy((uint8_t*)Send.Data[Send.Data_Num], Data, 8);
		Send.Data_Num += 1;
	}
	else {
		memcpy((uint8_t*)Send.Data[Data_Num_Max - 1], Data, 8);
	}
}

void Zigbee_Int_Send_Data(uint8_t* Data) {
	Zigbee_Send_Data(Data);
}

bool Send_Flag = true; //�����Ƿ����з��ͱ�־λ

void Zigbee_Send_Int_Run(void) {
	if (Send_Flag == true) {
		if (Send.Data_Num){
			Send.Data_Num -= 1;
			Zigbee_Send_Data_Base_Api((u8 *)Send.Data[Send.Data_Num], 8);
		}
	}
}
