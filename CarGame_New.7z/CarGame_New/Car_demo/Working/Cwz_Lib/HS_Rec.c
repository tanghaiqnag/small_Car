#include <stdio.h>
#include "string.h"
#include "HS_Rec.h"
#include "HS_Send.h"

HS_Com_Typ Rec_Com;

/*
���ܣ������յ���ָ���Ƿ����
���� true false
*/
bool Rec_Data_Test(const uint8_t *Data_In){
	if ((Data_In[0] == HS_Com_Head_00) && (Data_In[1] == HS_Com_Head_01)) {
		if (Out_Data_Judgment(Data_In, 6) == Data_In[6]) {
			Rec_Com.Host_Dat = (HS_Data_Tran_Com_Typ)Data_In[2];
			memcpy(Rec_Com.Deputy_Data, Data_In+3, 3);
			return true;
		}
	}
	return false;
}
/****************************************************/
/****************************************************/
HS_Message_Back_Typ 	HS_Rec_Message_Back;
HS_Data_Typ						HS_Rec_Message_Data;

void HS_Data_Con(HS_Com_Typ *In_Rec_Com){
	
	switch (In_Rec_Com->Host_Dat){	
		case Message_Back:		
		{
			HS_Rec_Message_Back.Process_HostCom = (HS_Data_Tran_Com_Typ)In_Rec_Com->Deputy_Data[0];
			HS_Rec_Message_Back.Process_Num = In_Rec_Com->Deputy_Data[1];
			HS_Rec_Message_Back.Process_Rec = In_Rec_Com->Deputy_Data[2];
			HS_Rec_Message_Back.Rec_Flag = true;
		}
		break;
		case Data_Info:
		{
			HS_Rec_Message_Data.Fun_Data_Num = (HS_Interactive_Com_Typ)In_Rec_Com->Deputy_Data[0];
			HS_Rec_Message_Data.Fun_Data_Len = In_Rec_Com->Deputy_Data[1];
			HS_Rec_Message_Data.Rec_Flag = false;
			HS_Send_Back_Com(Data_Info, 0, true);
		}
		break;
		case Data:
		{
			//In_Rec_Com->Deputy_Data[0]Ϊ�ڼ���ָ�ÿ��ָ��ֻ�ܽ���2���ֽڵ�����
			memcpy(HS_Rec_Message_Data.Data + In_Rec_Com->Deputy_Data[0]*2, In_Rec_Com->Deputy_Data+1, 2);
			HS_Send_Back_Com(Data, In_Rec_Com->Deputy_Data[0], true); //���ݽ��ճɹ�
		}
		break;
		case Data_Over:
		{
			HS_Rec_Message_Data.Rec_Flag = true;
			HS_Send_Back_Com(Data_Over, HS_Rec_Message_Data.Fun_Data_Len , true);
		}
		break;
		default: 
		break;
	}
}


/*
���ܣ����ӳ�ZigbeeͨѶ���к���
���룺
			Com_In 8λָ������ ������������ӳ���ͨѶЭ��
*/
void HS_Rec_Fun_Run(const uint8_t *Com_In){
	if (Rec_Data_Test(Com_In) == true) {
		HS_Data_Con(&Rec_Com);
	}
}
