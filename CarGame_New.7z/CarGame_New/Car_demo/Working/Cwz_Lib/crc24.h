#ifndef _crc24_h
#define _crc24_h


extern unsigned char HwArr[6]; 
extern unsigned char zifuchuan[20];
extern unsigned char now[2];
extern unsigned char ruku[2];


void luxianbianzhi(unsigned char *luxian);
void tiquqizuobiaodian(unsigned char liebiao[7][2]);
void luxianjiehe(char *s1,char *s2);
void chekuxunzhi(unsigned char *luxian);

//��һ����д���飬���鳤��

void CrcFun(unsigned char *Arr,unsigned char ArrLen);


#endif


