#include "gpio.h"
#include "tba.h"

#ifdef GuoSai_V1_0 //������IO��Ϣ
void MX_GPIO_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE);
	
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource14,GPIO_AF_SWJ);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource13,GPIO_AF_SWJ);
	
	SYN7318RESET_Initial_Value_Init;
	CD_4051_COM_Initial_Value_Init;
	CD_4051_A_Initial_Value_Init;
	CD_4051_B_Initial_Value_Init;
	CD_4051_C_Initial_Value_Init;
	
	GPIO_InitStruct.GPIO_Pin = SYN7318RESET_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(SYN7318RESET_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = CD_4051_COM_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(CD_4051_COM_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = CD_4051_A_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(CD_4051_A_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = CD_4051_B_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(CD_4051_B_GPIO_Port,&GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin = CD_4051_C_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz; 
	GPIO_Init(CD_4051_C_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = INT0_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;		//����
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   //���� 
	GPIO_Init(INT0_GPIO_Port,&GPIO_InitStruct);						
							
	GPIO_InitStruct.GPIO_Pin = SER_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; //�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(SER_GPIO_Port,&GPIO_InitStruct);
					
	GPIO_InitStruct.GPIO_Pin = RCK_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; //�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(RCK_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = SCK_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;  		//ͨ�����
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//������� 
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz; 
	GPIO_Init(SCK_GPIO_Port,&GPIO_InitStruct);	
	
	GPIO_InitStruct.GPIO_Pin = ADDR_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(ADDR_GPIO_Port,&GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin = IIC_SCL_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(IIC_SCL_GPIO_Port,&GPIO_InitStruct);
	
	
	//ʹ��4051������Ҫ�ڳ�ʼ��4051���ź��ڽ��г�ʼ����ʼֵ
	RI_TXD_Initial_Value_Init;
	INC_Initial_Value_Init;
	BEEP_Initial_Value_Init;
	L_LED_Initial_Value_Init;
	R_LED_Initial_Value_Init;
	SMG_A_Initial_Value_Init;
	SMG_B_Initial_Value_Init;
}
#endif
#ifdef ShengSai_V1_0 //ʡ����IO��Ϣ
void MX_GPIO_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE);
	
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource14,GPIO_AF_SWJ);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource13,GPIO_AF_SWJ);
	
//	SYN7318RESET_Initial_Value_Init;
//	CD_4051_COM_Initial_Value_Init;
//	CD_4051_A_Initial_Value_Init;
//	CD_4051_B_Initial_Value_Init;
//	CD_4051_C_Initial_Value_Init;
	
//	GPIO_InitStruct.GPIO_Pin = SYN7318RESET_Pin;
//	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
//	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
//	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
//	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
//	GPIO_Init(SYN7318RESET_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = INC_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(INC_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = SMG_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(SMG_GPIO_Port,&GPIO_InitStruct);
	
//	GPIO_InitStruct.GPIO_Pin = BEEP_Pin;
//	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
//	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
//	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
//	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
//	GPIO_Init(BEEP_GPIO_Port,&GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin = RI_TXD_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz; 
	GPIO_Init(RI_TXD_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = JP_09_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(JP_09_GPIO_Port,&GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin = JP_11_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//�������
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz; 
	GPIO_Init(JP_11_GPIO_Port,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = INT0_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;		//����
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   //���� 
	GPIO_Init(INT0_GPIO_Port,&GPIO_InitStruct);			

	GPIO_InitStruct.GPIO_Pin = INT0_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;		//����
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   //���� 
	GPIO_Init(INT0_GPIO_Port,&GPIO_InitStruct);
	
	
							
//	GPIO_InitStruct.GPIO_Pin = SER_Pin;
//	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
//	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; //�������
//	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
//	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
//	GPIO_Init(SER_GPIO_Port,&GPIO_InitStruct);
					
//	GPIO_InitStruct.GPIO_Pin = RCK_Pin;
//	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;			//���
//	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; //�������
//	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
//	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
//	GPIO_Init(RCK_GPIO_Port,&GPIO_InitStruct);
//	
//	GPIO_InitStruct.GPIO_Pin = SCK_Pin;
//	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;  		//ͨ�����
//	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; 		//������� 
//	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   		//����
//	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz; 
//	GPIO_Init(SCK_GPIO_Port,&GPIO_InitStruct);	
	
	GPIO_InitStruct.GPIO_Pin = ADDR_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(ADDR_GPIO_Port,&GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin = IIC_SCL_Pin;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(IIC_SCL_GPIO_Port,&GPIO_InitStruct);
	
	
	//ʹ��4051������Ҫ�ڳ�ʼ��4051���ź��ڽ��г�ʼ����ʼֵ
	RI_TXD_Initial_Value_Init;
	INC_Initial_Value_Init;
	BEEP_Initial_Value_Init;
	L_LED_Initial_Value_Init;
	R_LED_Initial_Value_Init;
//	SMG_A_Initial_Value_Init;
//	SMG_B_Initial_Value_Init;
}
#endif
